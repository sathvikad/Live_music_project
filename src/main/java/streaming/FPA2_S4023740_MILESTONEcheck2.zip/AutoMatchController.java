package streaming.live_music;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;
import java.util.List;

public class AutoMatchController {

    @FXML
    private TableView<MatchedRequest> matchedRequestTable;
    @FXML
    private TableColumn<MatchedRequest, String> eventNameColumn;
    @FXML
    private TableColumn<MatchedRequest, String> venueNameColumn;
    @FXML
    private TableColumn<MatchedRequest, String> statusColumn;

    private final JobRequestDAO jobRequestDAO = new JobRequestDAO();

    @FXML
    public void initialize() {
        eventNameColumn.setCellValueFactory(new PropertyValueFactory<>("eventName"));
        venueNameColumn.setCellValueFactory(new PropertyValueFactory<>("venueName"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        ObservableList<MatchedRequest> matchedRequests = FXCollections.observableArrayList(autoMatch(jobRequestDAO.getAllJobRequests()));
        matchedRequestTable.setItems(matchedRequests);
    }

    private List<MatchedRequest> autoMatch(List<JobRequest> jobRequests) {
        List<MatchedRequest> matchedList = new ArrayList<>();
        for (JobRequest jobRequest : jobRequests) {
            matchedList.add(new MatchedRequest(jobRequest.getEventName(), "Sample Venue", "Matched"));
        }
        return matchedList;
    }

    @FXML
    private void handleBack() {
        SceneSwitcher.switchScene("/streaming/live_music/managerDashboard.fxml");
    }

    @FXML
    private void handleStartMatching() {
        System.out.println("Starting matching logic...");
    }
}
