package streaming.live_music;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LoginController {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;

    private static final Path USERS_FILE_PATH = Paths.get("src/main/resources/streaming/live_music/users.txt");

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Login Error", "Please enter both username and password.");
            return;
        }

        // Ensure the users.txt file exists
        ensureUsersFileExists();

        String role = validateCredentials(username, password);
        if (role != null) {
            showAlert("Success", "Login successful.");
            if (role.equalsIgnoreCase("Manager")) {
                SceneSwitcher.switchScene("/streaming/live_music/managerDashboard.fxml");
            } else if (role.equalsIgnoreCase("Staff")) {
                SceneSwitcher.switchScene("/streaming/live_music/staffDashboard.fxml");
            } else {
                showAlert("Error", "Unknown role: " + role);
            }
        } else {
            showAlert("Login Error", "Invalid username or password.");
        }
    }

    private String validateCredentials(String username, String password) {
        try (BufferedReader reader = Files.newBufferedReader(USERS_FILE_PATH)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userDetails = line.split(",");
                if (userDetails.length == 5 && userDetails[0].trim().equals(username) && userDetails[1].trim().equals(password)) {
                    return userDetails[4].trim();  // Return role (Manager or Staff)
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Unable to read user data.");
            e.printStackTrace();
        }
        return null;
    }

    private void ensureUsersFileExists() {
        try {
            if (!Files.exists(USERS_FILE_PATH)) {
                Files.createDirectories(USERS_FILE_PATH.getParent());
                try (BufferedWriter writer = Files.newBufferedWriter(USERS_FILE_PATH)) {
                    writer.write("admin,admin123,Admin,User,Manager\n");
                    writer.write("staff,staff123,Staff,Member,Staff\n");
                    System.out.println("Default users.txt created.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSignUpRedirect() {
        SceneSwitcher.switchScene("/streaming/live_music/register.fxml");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
